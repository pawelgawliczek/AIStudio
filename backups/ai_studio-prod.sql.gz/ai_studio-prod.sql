--
-- PostgreSQL database dump
--

\restrict wt5oh492dl6ORRZK80hUF2znrjpL5DZe07w2Lk3hchnscbIE04pMdFPs7NSY3bK

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg12+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict wt5oh492dl6ORRZK80hUF2znrjpL5DZe07w2Lk3hchnscbIE04pMdFPs7NSY3bK

